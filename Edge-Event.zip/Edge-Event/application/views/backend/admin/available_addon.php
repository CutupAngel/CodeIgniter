<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-primary" data-collapsed="0">
      <div class="panel-heading">
        <div class="panel-title">
          <?php echo get_phrase('all_available_addons'); ?>
        </div>
      </div>
      <div class="panel-body">
        <iframe scrolling="yes" class="col-md-12 w-100" frameborder="none" style="height: 510px;" src="#"></iframe>
      </div>
    </div>
  </div>
</div>