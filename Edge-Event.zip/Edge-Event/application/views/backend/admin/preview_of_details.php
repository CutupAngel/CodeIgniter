<div class="row">
  <div class="col-12">
    <img src="<?php echo base_url('assets/backend/images/preview/'.$param2.'.png'); ?>" alt="" width="100%">
  </div>
</div>
