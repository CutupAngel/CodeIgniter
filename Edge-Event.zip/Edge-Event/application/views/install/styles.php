<link rel="stylesheet" href="<?php echo base_url('assets/backend/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css');?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/font-icons/entypo/css/entypo.css');?>" type="text/css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/bootstrap.css');?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-core.css');?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-theme.css');?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/neon-forms.css');?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url('assets/backend/css/custom.css');?>" type="text/css">
<script src="<?php echo base_url('assets/backend/js/jquery-2.2.4.min.js'); ?>" charset="utf-8"></script>
